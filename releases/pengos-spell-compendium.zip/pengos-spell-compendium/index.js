console.log("Loading pengos-spell-compendium spells...");



console.log("Done loading pengos-spell-compendium spells.");