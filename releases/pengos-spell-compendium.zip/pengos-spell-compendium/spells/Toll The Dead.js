class TollTheDead extends Item5e {
    constructor(data, options) {
        super(data, options);
    }

    async castSpell() {
        console.log("Casting Toll The Dead");
    }
}