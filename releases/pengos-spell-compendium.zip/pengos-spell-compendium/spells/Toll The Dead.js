class TollTheDead extends Item {
    constructor(data, options) {
        super(data, options);
    }

    async castSpell() {
        console.log("Casting Toll The Dead");
    }
}